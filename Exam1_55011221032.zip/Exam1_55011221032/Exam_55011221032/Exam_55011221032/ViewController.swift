//
//  ViewController.swift
//  Exam_55011221032
//
//  Created by Student on 10/10/2557 BE.
//  Copyright (c) 2557 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var name: String = ""
    var volume:Int = 0
    var price: Double = 0.0
    var total: Double = 0.0
    
    let cellIdentifier = "cellIdentifier"
    var tableData = ["\(nametf.text) ราคาหุ้นขึ้น 3% : กำไร  บาท","\(nametf.text) ราคาหุ้นขึ้น 5% : กำไร  บาท","\(nametf.text) ราคาหุ้นขึ้น 10% : กำไร  บาท"]
    @IBOutlet var tableView: UITableView!
    
    @IBOutlet var totaltf: UITextField!
    @IBOutlet var volumetf: UITextField!
    @IBOutlet var pricetf: UITextField!
    @IBOutlet var nametf: UITextField!
    
    
    
    @IBAction func textname(sender: AnyObject) {
    }
    
    @IBAction func tfvolume(sender: AnyObject) {
    }
    @IBAction func tfprice(sender: AnyObject) {
    }
    @IBAction func tftotal(sender: AnyObject) {
        totaltf.resignFirstResponder()
        
        
    }
    
    @IBAction func totalbutton(sender: AnyObject) {
    }
        total= Int(volumetf.text) * Double(pricetf.text)
        totaltf.text = "\(total)"
    
    @IBAction func profit(sender: AnyObject) {
        
        
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCellWithIdentifier(self.cellIdentifier) as UITableViewCell
        
        cell.textLabel!.text = tableData[indexPath.row]
        
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var up1 = Int(volumetf)*Double(pricetf)*3/100
        var up2 = Int(volumetf)*Double(pricetf)*5/100
        var up3 = Int(volumetf)*Double(pricetf)*10/100
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: self.cellIdentifier)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    

}

